<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
// print_r($_POST);
if($_POST)
{
    $post = $_POST;
    // echo "<pre>";
    // print_r($post);

    
    if($post['resume_id'] && $post['position'] && $post['company'] && $post['started'] && $post['ended'] && $post['job_dec'])
    
    {

        
        $resume_id = $post['resume_id'];
        $position = $post['position'];
        $company = $post['company'];
        $started = $post['started'];
        $ended = $post['ended'];
        $job_dec = $post['job_dec'];
        $post2 = $post;
        unset($post['slug']);
       
        try{

          $db->query("INSERT INTO experience (resume_id , position , company,started,ended,job_dec) values('$resume_id','$position','$company','$started','$ended','$job_dec')");
          
            //$db->query($query);
             
            $fn->setAlert('Experience details added!');
            $fn->redirect('../updateresume.php?resume='.$post2['slug']);
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../updateresume.php?resume='.$post2['slug']);
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../updateresume.php?resume='.$post2['slug']);
    }
}else{

    $fn->redirect('../login.php');
}
?>