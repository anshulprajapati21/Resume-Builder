<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    if($post['password'])
    {

        $password = $post['password'];
        $email = $fn->getSession('email');
        
        $db->query("UPDATE users SET password = '$password' WHERE email_id='$email'");
        $fn->setAlert('Password is changed');
        $fn->redirect('../login.php');
        
    

    }else{
        $fn->setError('please enter your new Password ');
        $fn->redirect('../change-password.php');
    }
}else{

    $fn->redirect('../change-password.php');
}
?>