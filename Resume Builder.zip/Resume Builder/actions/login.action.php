<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    if($post['email_id'] && $post['password'])
    {

        // $full_name = $db->real_escape_string($post['full_name']);
        // $email_id = $db->real_escape_string($post['email_id']);
        // $password = $db->real_escape_string($post['password']);

        $email_id = $post['email_id'];
        $password = $post['password'];
        //$password = md5($db->real_escape_string($post['password'])); // md5 - encrypt password


        $result = $db->query("SELECT id,full_name FROM users WHERE(email_id='$email_id' && password = '$password')");
        $result = $result->fetch_assoc();
        if($result){
            //print_r($result);
            $fn->setAuth($result);
            $fn->setAlert('Logged in !');
            $fn->redirect('../myresumes.php');
            
        }else{
            $fn->setError('Incorrect email id or password');
            $fn->redirect('../login.php');
        }

        
        
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../login.php');
    }
}else{

    $fn->redirect('../login.php');
}
?>