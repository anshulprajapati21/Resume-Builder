<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    print_r($post);
    if($post['resume_id'] && $post['background'])
    
    {
        $post['tile'] = $post['background'];
      
        // $font = $post['font'];
        $tile = $db->real_escape_string($post['tile']);

           $query = "UPDATE resumes SET background='$tile' WHERE id ={$post['resume_id']}";
        //    echo "$query";
          
            $db->query($query);
            
        

    }
}
?>