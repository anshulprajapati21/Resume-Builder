<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
// print_r($_POST);
if($_GET)
{
    $post = $_GET;
    
    if($post['id'] && $post['resume_id'] )
    
    {

       
        try{

          
          $query = "DELETE FROM skills WHERE id = {$post['id']}  AND resume_id={$post['resume_id']}";

            $db->query($query);
             
            $fn->setAlert('Skills deleted !');
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../updateresume.php?resume='.$post['slug']);
    }
}else{

    $fn->redirect('../updateresume.php?resume='.$post['slug']);
}
?>