<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
// print_r($_POST);
if($_POST)
{
    $post = $_POST;
    // echo "<pre>";
    // print_r($post);

    
    if($post['resume_id'] && $post['skills']  )
    
    {

        
        $resume_id = $post['resume_id'];
        $skills = $post['skills'];
        // $institute = $post['institute'];
        // $started = $post['started'];
        // $ended = $post['ended'];
        $post2 = $post;
        unset($post['slug']);
       
        try{

          $db->query("INSERT INTO skills (resume_id , skills ) values('$resume_id','$skills')");
          
            //$db->query($query);
             
            $fn->setAlert('Skills added!');
            $fn->redirect('../updateresume.php?resume='.$post2['slug']);
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../updateresume.php?resume='.$post2['slug']);
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../updateresume.php?resume='.$post2['slug']);
    }
}else{

    $fn->redirect('../login.php');
}
?>