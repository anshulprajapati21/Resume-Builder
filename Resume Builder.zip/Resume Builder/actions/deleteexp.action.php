<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
// print_r($_POST);
if($_GET)
{
    $post = $_GET;
    // echo "<pre>";
    // print_r($post);

    
    if($post['id'] && $post['resume_id'] )
    
    {

        
        // $resume_id = $post['resume_id'];
        // $position = $post['position'];
        // $company = $post['company'];
        // $started = $post['started'];
        // $ended = $post['ended'];
        // $job_dec = $post['job_dec'];
        // $post2 = $post;
        // unset($post['slug']);
       
        try{

          //$db->query("INSERT INTO experience (resume_id , position , company,started,ended,job_dec) values('$resume_id','$position','$company','$started','$ended','$job_dec')");
          $query = "DELETE FROM experience WHERE id = {$post['id']}  AND resume_id={$post['resume_id']}";

            $db->query($query);
             
            $fn->setAlert('Experience deleted !');
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../updateresume.php?resume='.$post['slug']);
    }
}else{

    $fn->redirect('../login.php');
}
?>