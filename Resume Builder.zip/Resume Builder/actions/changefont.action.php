<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    print_r($post);
    if($post['resume_id'] && $post['font'])
    
    {
      
        // $font = $post['font'];
        $font = $db->real_escape_string($post['font']);

           $query = "UPDATE resumes SET font='$font' WHERE id ={$post['resume_id']}";
        //    echo "$query";
          
            $db->query($query);
            
        

    }
}
?>