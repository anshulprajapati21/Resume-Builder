<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';


$slug = $_GET['resume']??'';
$resumes =  $db->query("SELECT * FROM resumes WHERE ( slug = '$slug' AND user_id =".$fn->Auth()['id'].")");
$resume = $resumes->fetch_assoc();   
if(!$resume){
    $fn->redirect('myresumes.php');
}

$exps = $db->query("SELECT * FROM experience WHERE (resume_id = ".$resume['id'].")");
$exps = $exps->fetch_all(1);

$edus = $db->query("SELECT * FROM educations WHERE (resume_id = ".$resume['id'].")");
$edus = $edus->fetch_all(1);

$skills = $db->query("SELECT * FROM skills WHERE (resume_id = ".$resume['id'].")");
$skills = $skills->fetch_all(1);


        
$full_name = $resume['full_name'];
$email_id = $resume['email_id'];
$objective = $resume['objective'];
$mobile_no = $resume['mobile_no'];
$dob = $resume['dob'];
$gender = $resume['gender'];
$religion = $resume['religion'];
$nationality = $resume['nationality'];
$marital_status = $resume['marital_status'];
$hobbies = $resume['hobbies'];
$languages = $resume['languages'];
$address = $resume['address'];
$resume_title = $resume['resume_title'];
$resume_title.=' Clone_'.time();

$ak = time();
$authid = $fn->Auth()['id'];

try{

    // $query = "INSERT INTO resumes";
    // $query.="($columns) ";
    // $query.="VALUES($values)";
   $query="INSERT INTO resumes (full_name,email_id,objective,mobile_no,dob,gender,religion,nationality,marital_status,hobbies,languages,address,slug,update_at,user_id,resume_title) values
   ('$full_name','$email_id','$objective','$mobile_no','$dob','$gender','$religion','$nationality','$marital_status','$hobbies','$languages','$address','".$fn->randomstring()."','$ak','$authid','$resume_title')";
  
    $db->query($query);
    $new_resume_id=$db->insert_id;

    foreach($exps as $exp){
        $query2 = "INSERT INTO experience(resume_id,position,company,job_dec,started,ended) VALUES($new_resume_id,'{$exp['position']}',
        '{$exp['company']}','{$exp['job_dec']}','{$exp['started']}','{$exp['ended']}')";
        $db->query($query2);
    }

    foreach($edus as $edu){
        $query3 = "INSERT INTO educations(resume_id,course,institute,started,ended) VALUES($new_resume_id,'{$edu['course']}',
        '{$edu['institute']}','{$edu['started']}','{$edu['ended']}')";
        $db->query($query3);
    }

    foreach($skills as $skill){
        $query4 = "INSERT INTO skills(resume_id,skills) VALUES($new_resume_id,'{$skill['skills']}')";
        $db->query($query4);
    }
   
    //echo $query;
    //die();  
    $fn->setAlert('Clone Created !');
    $fn->redirect('../myresumes.php');
}catch(Exception $error){
    $fn->setError($error->getMessage());
    $fn->redirect('../myresume.php');
    //echo $error->getMessage();
}       



?>