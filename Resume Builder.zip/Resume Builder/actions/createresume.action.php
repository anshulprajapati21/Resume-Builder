<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    // echo "<pre>";
    // print_r($post);

    
    if($post['full_name'] && $post['email_id'] && $post['objective'] && $post['mobile_no'] && $post['dob']
    && $post['religion'] && $post['nationality'] && $post['marital_status'] && $post['hobbies'] && $post['languages']
    && $post['address'])
    
    {

        
        $full_name = $post['full_name'];
        $email_id = $post['email_id'];
        $objective = $post['objective'];
        $mobile_no = $post['mobile_no'];
        $dob = $post['dob'];
        $gender = $post['gender'];
        $religion = $post['religion'];
        $nationality = $post['nationality'];
        $marital_status = $post['marital_status'];
        $hobbies = $post['hobbies'];
        $languages = $post['languages'];
        $address = $post['address'];
        $resume_title = $post['resume_title'];
        
        //     $columns ='';
        //     $values ='';
        // foreach($post as $index=>$value){
        //     //$$index = $db->real_escape_string($value);
        //     $columns.=$index.',';
        //     $values.="'$value',";
        // }
        // echo $columns;
        // echo $values;
        // die();
        
        // $columns.='slug,updated_at';
        // $values.="'".$fn->randomstring()."',".time();
        $ak = time();
        $authid = $fn->Auth()['id'];
       
        try{

            // $query = "INSERT INTO resumes";
            // $query.="($columns) ";
            // $query.="VALUES($values)";
           $db->query("INSERT INTO resumes (full_name,email_id,objective,mobile_no,dob,gender,religion,nationality,marital_status,hobbies,languages,address,slug,update_at,user_id,resume_title) values
           ('$full_name','$email_id','$objective','$mobile_no','$dob','$gender','$religion','$nationality','$marital_status','$hobbies','$languages','$address','".$fn->randomstring()."','$ak','$authid','$resume_title')");
          
            // $db->query($query);
            // echo $query;
            // die();  
            $fn->setAlert('Resume Added !');
            $fn->redirect('../myresumes.php');
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../createresume.php');
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../createresume.php');
    }
}else{

    $fn->redirect('../login.php');
}
?>