<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
// print_r($_POST);
if($_GET)
{
    $post = $_GET;
    
    if($post['id'] )
    
    {
        
        $authid = $fn->Auth()['id'];
       
        try{

          
          $query = "DELETE resumes,skills,educations,experience FROM resumes
                    LEFT JOIN skills ON resumes.id = skills.resume_id
                    LEFT JOIN educations ON resumes.id = educations.resume_id
                    LEFT JOIN experience ON resumes.id = experience.resume_id
                    WHERE resumes.id = {$post['id']}  AND resumes.user_id = $authid";

            $db->query($query);
             
            $fn->setAlert('Resume deleted !');
            $fn->redirect('../myresumes.php');
        }catch(Exception $error){
            $fn->setError($error->getMessage());
           // echo $error->getMessage();
            $fn->redirect('../myresumes.php');
            echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../myresumes.php');
    }
}else{

    $fn->redirect('../myresumes.php');
}
?>