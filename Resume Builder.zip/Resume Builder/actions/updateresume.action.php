<?php
require '../assests/class/database.class.php';
require '../assests/class/function.class.php';
//print_r($_POST);
if($_POST)
{
    $post = $_POST;
    // echo "<pre>";
    // print_r($post);
    // die();
    
    if($post['id'] && $post['slug'] && $post['full_name'] && $post['email_id'] && $post['objective'] && $post['mobile_no'] && $post['dob']
    && $post['religion'] && $post['nationality'] && $post['marital_status'] && $post['hobbies'] && $post['languages']
    && $post['address'])
    
    {

        
        $full_name = $post['full_name'];
        $email_id = $post['email_id'];
        $objective = $post['objective'];
        $mobile_no = $post['mobile_no'];
        $dob = $post['dob'];
        $gender = $post['gender'];
        $religion = $post['religion'];
        $nationality = $post['nationality'];
        $marital_status = $post['marital_status'];
        $hobbies = $post['hobbies'];
        $languages = $post['languages'];
        $address = $post['address'];
        $resume_title = $post['resume_title'];
        
        
       
        try{

            // $query = "INSERT INTO resumes";
            // $query.="($columns) ";
            // $query.="VALUES($values)";
           $query = "UPDATE resumes SET full_name='$full_name',email_id='$email_id',objective='$objective',mobile_no='$mobile_no',dob='$dob',gender='$gender',religion='$religion',
           nationality='$nationality',marital_status='$marital_status',hobbies='$hobbies',languages='$languages',address='$address',resume_title='$resume_title' 
           WHERE id ={$post['id']} AND slug = '{$post['slug']}'";
           
          
            $db->query($query);
            //  echo $query;
            //  die();  
            $fn->setAlert('Resume Update !');
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
        }catch(Exception $error){
            $fn->setError($error->getMessage());
            $fn->redirect('../updateresume.php?resume='.$post['slug']);
            //echo $error->getMessage();
        }       
        

    }else{
        $fn->setError('please fill the form !');
        $fn->redirect('../updateresume.php?resume='.$post['slug']);
    }
}else{

    $fn->redirect('../updateresume.php?resume='.$post['slug']);
}
?>