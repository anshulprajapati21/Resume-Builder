<nav class="navbar bg-body-tertiary shadow">
        <div class="container">
            <a class="navbar-brand" href="myresumes.php">
                <img src="./assests/images/bookLogo.png" alt="Logo" height="24" class="d-inline-block align-text-top">
                Resume Builder
            </a>
            <div>
                <a href="profile.php" class="btn btn-sm btn-dark"><i class="bi bi-person-circle"  style="right: 20px;"></i> Profile</button>
                <a href="actions/logout.action.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-left"></i>LogOut</a>
            </div>
        </div>
    </nav>