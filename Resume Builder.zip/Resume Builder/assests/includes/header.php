<?php
require './assests/class/database.class.php';
require './assests/class/function.class.php'

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=@$title?></title>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./assests/images/bookLogo.png">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

	<style>
		body{
			/* height: 100vh; */
			background: rgb(249,249,249);
			background: radial-gradient(circle,rgb(249,249,249,1) 0%,rgb(240,232,127,1) 40%,rgb(246,243,132,1) 10%);
		}

		.form-signin{
			max-width: 360px;
			padding: 1rem;
		}
		.form-signin .form-floating{
			z-index: 2;
		}
		.form-signin input[type="text"]{
			margin-bottom: -1px;
			border-bottom-right-radius: 0;
			border-bottom-left-radius: 0;
		}
		.form-signin input[type="email"]{
			margin-bottom: -1px;
			border-radius: 0;

		}
		.form-signin input[type="password"]{
			margin-bottom: 10px;
			border-bottom-right-radius: 0;
			border-bottom-left-radius: 0;
		}
	</style>
</head>
<body class="">
<!-- <body class="d-flex align-items-center"> -->